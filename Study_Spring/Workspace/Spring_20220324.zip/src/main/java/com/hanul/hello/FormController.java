package com.hanul.hello;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class FormController {

	// ① HttpServletRequest 의 타입으로 파라미터 접근
	
	@RequestMapping ("/joinRequest")
	public String member(HttpServletRequest request, Model model) {
		// 클라이언트가 요청한 값을 받는다.
		model.addAttribute("name", request.getParameter("name") );
		model.addAttribute("gender", request.getParameter("gender") );
		model.addAttribute("email", request.getParameter("email") );
		return "member/info";
	}
	
	// ② @RequestParam 의 타입으로 파라미터 접근
	@RequestMapping ("/joinParam")
//	public String member(Model model, @RequestParam String name, String gender, String email) {
	public String member(Model model, String name, String gender, String email) {
		
		model.addAttribute("name", name);
		model.addAttribute("gender", gender);
		model.addAttribute("email", email);
		
		return "member/info";
	}
	
	@RequestMapping ("/member")	
	public String member() {
		return "member/join";
	}
	
}
