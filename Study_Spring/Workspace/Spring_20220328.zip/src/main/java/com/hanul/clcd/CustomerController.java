package com.hanul.clcd;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// 고객관리 페이지처리 @Controller 생성
@Controller
public class CustomerController {
	
	// 고객 관리 목록 요청
	@RequestMapping ("/list.cu")
	public String list(HttpSession session ) {
		
		session.setAttribute("category", "cu");
		return "customer/list";		// views/customer/list.jsp 파일을 호출
	}
	
}
