package com.hanul.action;

import javax.servlet.http.HttpServletRequest;

public interface Action {
	// 실제 처리할 비지니스 로직에서 구현할 메소드 정의
	
}
